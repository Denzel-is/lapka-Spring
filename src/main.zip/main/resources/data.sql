-- Создаём пару ролей
INSERT INTO roles (role_id, role_name) VALUES (1, 'ROLE_ADMIN');
INSERT INTO roles (role_id, role_name) VALUES (2, 'ROLE_USER');

-- Пример категорий
INSERT INTO categories (id, name) VALUES (1, 'Пиццы');
INSERT INTO categories (id, name) VALUES (2, 'Гарниры');
INSERT INTO categories (id, name) VALUES (3, 'Напитки');

-- Пиццы (demo)
INSERT INTO pizzas (id, name, description, image_url, price, category_id)
VALUES (1, 'Маргарита', 'Томатный соус, сыр моцарелла', 'https://example.com/margarita.jpg', 350.00, 1),
       (2, 'Пепперони', 'Пикантная пепперони, сыр', 'https://example.com/pepperoni.jpg', 400.00, 1),
       (3, 'Гавайская', 'Курица, ананас, сыр', 'https://example.com/hawaiian.jpg', 450.00, 1);

-- Гарнир
INSERT INTO pizzas (id, name, description, image_url, price, category_id)
VALUES (4, 'Картофель фри', 'Картошка, масло, соль', 'https://example.com/fries.jpg', 100.00, 2);

-- Напиток
INSERT INTO pizzas (id, name, description, image_url, price, category_id)
VALUES (5, 'Кола', 'Газированный напиток', 'https://example.com/cola.jpg', 80.00, 3);

-- Пример пользователя admin (пароль должен быть захеширован, здесь пример bcrypt на 'admin')
INSERT INTO users (id, username, password, full_name)
VALUES (1, 'admin',
        '$2a$10$e6Swfn0Io2h0TBBjkCR0XelMrld1EEtLNedxTefEBFoK2Fv5oNn22',
        'Администратор');

-- Привязка роли админу
INSERT INTO user_roles (user_role_id, user_id, role_id) VALUES (1, 1, 1);
