-- Удалим таблицы, если уже существуют (CASCADE позволяет удалить связанные объекты)
DROP TABLE IF EXISTS payment_info CASCADE;
DROP TABLE IF EXISTS order_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS pizzas CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
DROP TABLE IF EXISTS user_roles CASCADE;
DROP TABLE IF EXISTS roles CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Создаём таблицу users
CREATE TABLE users (
                       id SERIAL PRIMARY KEY,
                       username VARCHAR(255) NOT NULL UNIQUE,
                       password VARCHAR(255) NOT NULL,
                       full_name VARCHAR(255)
);

-- Создаём таблицу roles
CREATE TABLE roles (
                       role_id SERIAL PRIMARY KEY,
                       role_name VARCHAR(255) NOT NULL UNIQUE
);

-- Связующая таблица user_roles (многие ко многим)
CREATE TABLE user_roles (
                            user_role_id SERIAL PRIMARY KEY,
                            user_id INT NOT NULL,
                            role_id INT NOT NULL,
                            CONSTRAINT fk_user FOREIGN KEY(user_id) REFERENCES users(id),
                            CONSTRAINT fk_role FOREIGN KEY(role_id) REFERENCES roles(role_id)
);

-- Категории (Пиццы, Напитки, Гарниры и т.д.)
CREATE TABLE categories (
                            id SERIAL PRIMARY KEY,
                            name VARCHAR(255) NOT NULL UNIQUE
);

-- Таблица для товаров (пицц и т.д.)
CREATE TABLE pizzas (
                        id SERIAL PRIMARY KEY,
                        name VARCHAR(255),
                        description TEXT,
                        image_url VARCHAR(255),
                        price NUMERIC(10,2),
                        category_id INT,
                        CONSTRAINT fk_category FOREIGN KEY(category_id) REFERENCES categories(id)
);

-- Таблица заказов
CREATE TABLE orders (
                        id SERIAL PRIMARY KEY,
                        created_at TIMESTAMP,
                        user_id INT,
                        CONSTRAINT fk_user_order FOREIGN KEY(user_id) REFERENCES users(id)
);

-- Позиции в заказе (какие товары и в каком количестве)
CREATE TABLE order_items (
                             id SERIAL PRIMARY KEY,
                             pizza_id INT,
                             quantity INT,
                             order_id INT,
                             CONSTRAINT fk_pizza FOREIGN KEY(pizza_id) REFERENCES pizzas(id),
                             CONSTRAINT fk_order FOREIGN KEY(order_id) REFERENCES orders(id)
);

-- Оплата (1:1 к заказу)
CREATE TABLE payment_info (
                              id SERIAL PRIMARY KEY,
                              card_number VARCHAR(255),
                              card_holder_name VARCHAR(255),
                              address VARCHAR(255),
                              city VARCHAR(255),
                              postal_code VARCHAR(20),
                              order_id INT UNIQUE,
                              CONSTRAINT fk_order_payment FOREIGN KEY(order_id) REFERENCES orders(id)
);
